from django.http import HttpResponse
from django.shortcuts import render, redirect
from .forms import loginForm
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test

def is_veterinario(user):
    return user.groups.filter(name='Veterinario').exists()
def is_recepcionista(user):
    return user.groups.filter(name='Recepcionista').exists()

def login_view(request):
    if request.method == 'POST':
        form = loginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user) # Inicia sesión del usuario

                #luego se verifica el grupo al que pertenece el usuario
                if user.groups.filter(name='Recepcionista').exists():
                    return redirect("/menu") #se estima donde irá, ya que aún no está lista la plantilla
                elif user.groups.filter(name='Veterinario').exists():
                    return redirect("/fichas-medicas") #se estima donde irá, ya que aún no está lista la plantilla
                #se considera que si NO pertenece a ninguno de los otros permisos será dirigido al panel de administración
                return redirect("/admin/")
            else:
                messages.error(request, 'Nombre de usuario o contraseña incorrectos')
    else:
        form = loginForm()

    return render(request, 'login.html', {"form": form})

@login_required
@user_passes_test(is_recepcionista)
def home(request):
    return render(request, 'home.html')

@login_required
@user_passes_test(is_veterinario)
def lista(request):
    return render(request, 'lista.html')

@login_required
@user_passes_test(is_recepcionista)
def menu_home(request):
    return render(request, 'menu.html')

@login_required
@user_passes_test(is_recepcionista)
def menu_reserve(request):
    return render(request, 'menu_reserva.html')

@login_required
@user_passes_test(is_recepcionista)
def lista_reservas(request):
    return render(request, 'lista_reservas.html')

@login_required
def perfil(request):
    return render(request, 'perfil.html')

