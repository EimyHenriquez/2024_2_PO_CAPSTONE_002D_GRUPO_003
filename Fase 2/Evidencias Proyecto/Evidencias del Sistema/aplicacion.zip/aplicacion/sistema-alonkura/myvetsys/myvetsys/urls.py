"""
URL configuration for myvetsys project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from myvetsys.views import login
from mysys.views import registrar_paciente, get_fichas_medicas, update_fallecido_status, lista_especialistas, get_ficha_detalle, crear_atencion, obtener_datos_paciente, actualizar_paciente, obtener_opciones_atencion,obtener_atenciones, notificar_llegada, marcar_leida, test_view, obtener_notificaciones, marcar_todo_como_leido, get_lista_reservas, guardar_reserva, obtener_valor_servicio, change_password, update_profile, logout_view
from .views import login_view, lista, home, menu_home, perfil,menu_reserve

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', login_view, name='login'),
    path('home/', home),
    path('lista/', lista),
    path('registrar-paciente/', registrar_paciente, name='registrar_paciente'),
    path('fichas-medicas/', get_fichas_medicas, name='get_fichas_medicas'),
    path('update_fallecido_status/', update_fallecido_status, name='update_fallecido_status'),
    path('get_ficha_detalle/<int:paciente_id>/', get_ficha_detalle, name='get_ficha_detalle'),
    path('crear_atencion/<int:paciente_id>/', crear_atencion, name='crear_atencion'),
    path('obtener_datos_paciente/<int:id_paciente>/', obtener_datos_paciente, name='obtener_datos_paciente'),
    path('actualizar_paciente/<int:paciente_id>/', actualizar_paciente, name='actualizar_paciente'),
    path('obtener_opciones_atencion/', obtener_opciones_atencion, name='obtener_opciones_atencion'),
    path('obtener_atenciones/<int:paciente_id>/', obtener_atenciones, name='obtener_atenciones'),
    path('prueba_disponibilidad/', lista_especialistas, name= 'prueba_disponibilidad'),
    path('menu/', menu_home, name='menu_home'),
    path('notificar-llegada/<int:paciente_id>/<int:veterinario_id>/', notificar_llegada, name='notificar_llegada'),
    path('notificaciones/marcar_leida/<int:notificacion_id>/', marcar_leida, name='marcar_leida'),
    path('api/notificaciones/', obtener_notificaciones, name='obtener_notificaciones'),  # Nueva línea
    path('test-views/', test_view, name='test-views'),
    path('api/marcar-todo-como-leido/', marcar_todo_como_leido, name='marcar_todo_como_leido'),
    path('miperfil/', perfil, name='miperfil'),
    path('cambiar-contraseña/', change_password, name='cambiar_contraseña'),
    path('obtener-valor-servicio/<int:servicio_id>/', obtener_valor_servicio, name='obtener_valor_servicio'),
    path('lista-reservas', get_lista_reservas, name='lista_reservas'),
    path('guardar-reserva/', guardar_reserva, name='guardar_reserva'),
    path('menu-reserva/', menu_reserve, name='menu_reserva'),
    path('update_profile/', update_profile, name='update_profile'),
    path('logout/', logout_view, name='logout')
    #path('ws/', include('mysys.routing'))
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
