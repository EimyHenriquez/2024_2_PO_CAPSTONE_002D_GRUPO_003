from channels.generic.websocket import AsyncWebsocketConsumer
import json

class NotificacionConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user_id = self.scope['url_route']['kwargs']['user_id']
        self.group_name = f'notifications_{self.user_id}'

        # Unirse al grupo de notificaciones
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )

    async def recibir_notificacion(self, event):
        notificacion = event['notificacion']

        # Enviar la notificación al cliente
        await self.send(text_data=json.dumps({
            'id': notificacion['id'],
            'message': notificacion['message'],
            'created_at': notificacion['created_at'],
            'is_read': notificacion['is_read'],
        }))