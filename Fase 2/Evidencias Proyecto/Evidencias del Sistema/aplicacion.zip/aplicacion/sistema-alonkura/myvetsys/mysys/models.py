from django.contrib.auth.models import User
from django.db import models

#NO SE CONSIDERAN IDs por clase. DJANGO LAS MANEJA AUTOMATICAMENTE.

class Rol(models.Model):
    rol = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.rol

class Comuna(models.Model):
    nombre_comuna = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.nombre_comuna

class DueñoPaciente(models.Model):
    rut = models.CharField(max_length=12, unique=True)
    primer_nombre = models.CharField(max_length=50)
    segundo_nombre = models.CharField(max_length=50, blank=True, null=True)
    apellido_paterno = models.CharField(max_length=50)
    apellido_materno = models.CharField(max_length=50, blank=True, null=True)
    direccion = models.CharField(max_length=50, blank=True, null=True)
    telefono = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    id_comuna = models.ForeignKey(Comuna, on_delete=models.CASCADE)

    def __str__(self):
        return self.rut

class Especialidad(models.Model):
    nombre_especialidad = models.CharField(max_length=50, unique=True)
    descripcion = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.nombre_especialidad
    
class Servicio(models.Model):
    servicio = models.CharField(max_length=50, unique=True)
    valor_servicio = models.DecimalField(max_digits=10, decimal_places=0)

    def __str__(self):
        return self.servicio

class Raza(models.Model):
    nombre_raza = models.CharField(max_length=50, unique=True)
    descripcion_raza = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.nombre_raza
    
class Especie(models.Model):
    nombre_especie = models.CharField(max_length=50, unique=True)
    descripcion = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.nombre_especie

class Paciente(models.Model):
    SEXO_CHOICES = [
        ('Macho', 'Macho'),
        ('Hembra', 'Hembra'),
    ]
    nombre_1 = models.CharField(max_length=50)
    nombre_2 = models.CharField(max_length=50, blank=True, null=True)
    apellido_1 = models.CharField(max_length=50, blank=True, null=True)
    apellido_2 = models.CharField(max_length=50, blank=True, null=True)
    sexo = models.CharField(max_length=6, choices=SEXO_CHOICES)
    fecha_nacimiento = models.DateField(blank=True, null=True)
    peso = models.DecimalField(max_digits=5, decimal_places=2)
    años = models.IntegerField(blank=True, null=True)
    meses = models.IntegerField(blank=True, null=True)
    color = models.CharField(max_length=50)
    tatuaje = models.CharField(max_length=50, blank=True, null=True)
    fecha_ingreso = models.DateField()
    numero_chip = models.CharField(max_length=50, unique=True, blank=True, null=True)
    chip = models.BooleanField(blank=True, null=True)
    alergia = models.BooleanField(blank=True, null=True)
    tipo_alergia = models.TextField(blank=True, null=True)
    descripción = models.TextField(blank=True, null=True)
    fallecido = models.BooleanField(blank=True, null=True)
    id_especie = models.ForeignKey(Especie, on_delete=models.CASCADE)
    id_raza = models.ForeignKey(Raza, on_delete=models.CASCADE)
    rut_dueño = models.ForeignKey(DueñoPaciente, to_field='rut', on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.nombre_1} {self.numero_chip}"

class EspecialistaSalud(models.Model):

    DIAS_SEMANA = [
        (1, 'Lunes'),
        (2, 'Martes'),
        (3, 'Miercoles'),
        (4, 'Jueves'),
        (5, 'Viernes'),
        (6, 'Sabado'),
        (7, 'Domingo'),
    ]

    rut = models.CharField(max_length=12, unique=True)
    primer_nombre = models.CharField(max_length=50)
    segundo_nombre = models.CharField(max_length=50, blank=True, null=True)
    apellido_paterno = models.CharField(max_length=50)
    apellido_materno = models.CharField(max_length=50, blank=True, null=True)
    fecha_nacimiento = models.DateField()
    fecha_contratación = models.DateField()
    telefono = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    id_comuna = models.ForeignKey(Comuna, on_delete=models.CASCADE)
    id_especialidad= models.ForeignKey(Especialidad, on_delete=models.CASCADE)
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='especialista', null=True, blank=True)

    def __str__(self):
        return f"{self.primer_nombre} {self.apellido_paterno}"

class Reserva(models.Model):
    id_reserva = models.AutoField(primary_key=True, unique=True)
    fecha = models.DateField(null=True)
    hora = models.TimeField(null=True)
    numero_ficha = models.ForeignKey(Paciente, on_delete=models.CASCADE, null=True, blank=True)
    especialista = models.ForeignKey(EspecialistaSalud, on_delete=models.CASCADE, null=True, blank=True)
    especialidad = models.ForeignKey(Especialidad, on_delete=models.CASCADE, null=True, blank=True)
    servicio = models.ForeignKey(Servicio, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"Reserva {self.id_reserva} — {self.numero_ficha} — {self.fecha} - {self.hora}"

class DisponibilidadEspecialista(models.Model):
    especialista = models.ForeignKey(EspecialistaSalud, on_delete=models.CASCADE, related_name='disponibilidades')
    dia = models.IntegerField(choices=EspecialistaSalud.DIAS_SEMANA)
    hora_inicio = models.TimeField()
    hora_fin = models.TimeField()

    def __str__(self):
        return f"{self.especialista} - {self.get_dia_display()} ({self.hora_inicio} a {self.hora_fin})"

class Funcionario(models.Model):
    rut = models.CharField(max_length=12, unique=True)
    primer_nombre = models.CharField(max_length=50)
    segundo_nombre = models.CharField(max_length=50, blank=True, null=True)
    apellido_paterno = models.CharField(max_length=50)
    apellido_materno = models.CharField(max_length=50, blank=True, null=True)
    fecha_nacimiento = models.DateField()
    fecha_contratación = models.DateField()
    telefono = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    id_comuna = models.ForeignKey(Comuna, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.primer_nombre} {self.segundo_nombre}"

class AtencionPaciente(models.Model):
    fecha_atencion = models.DateField()
    hora_atencion = models.TimeField()
    diagnostico = models.TextField()
    tratamiento = models.TextField()
    observacion = models.TextField()
    fecha_prox_atencion = models.DateField(blank=True, null=True)
    fecha_prox_vacunacion = models.DateField(blank=True, null=True)
    imagen_rayos = models.ImageField(upload_to='rayos/', blank=True, null=True)
    id_servicio = models.ForeignKey(Servicio, on_delete=models.CASCADE)
    numero_ficha = models.ForeignKey(Paciente, on_delete=models.CASCADE)
    id_especialista = models.ForeignKey(EspecialistaSalud, on_delete=models.CASCADE)

    def __str__(self):
      return f"Atención {self.fecha_atencion} a las {self.hora_atencion}"

class Notificacion(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f'Notification for {self.user.username}: {self.message}'