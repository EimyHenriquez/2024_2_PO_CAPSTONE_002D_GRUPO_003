from django.contrib import admin
from .models import Rol, Comuna, DueñoPaciente, Especialidad, Servicio, Raza, Especie, Paciente, Reserva, EspecialistaSalud, Funcionario, AtencionPaciente, DisponibilidadEspecialista

# Register your models here.

@admin.register(DueñoPaciente)
class DueñoPacienteAdmin(admin.ModelAdmin):
    list_display = ('rut', 'primer_nombre', 'apellido_paterno')

admin.site.register(Rol)
admin.site.register(Comuna)
admin.site.register(Especialidad)
admin.site.register(Servicio)
admin.site.register(Raza)
admin.site.register(Especie)
admin.site.register(Paciente)
admin.site.register(Reserva)
admin.site.register(EspecialistaSalud)
admin.site.register(Funcionario)
admin.site.register(AtencionPaciente)
admin.site.register(DisponibilidadEspecialista)