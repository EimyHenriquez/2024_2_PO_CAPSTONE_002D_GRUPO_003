from django.contrib.auth import logout
from gettext import translation
from django.shortcuts import render
from django.http import JsonResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import json
from datetime import datetime
# Create your views here.

#NOTIFICACIONES
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.http import JsonResponse

from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView

from audioop import reverse
from .models import Paciente, DueñoPaciente, Especie, Raza, Comuna, EspecialistaSalud, DisponibilidadEspecialista, Reserva, AtencionPaciente, Servicio, Notificacion


from .forms import PacienteForm, DueñoPacienteForm
from django.db.models import Q
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages

from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from .models import Paciente 
from django.http import HttpResponse

from django.contrib.auth.models import User

#Imports cambio contraseña
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
import logging
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required, user_passes_test
import os

LOG_DIR = 'logs/'


def is_veterinario(user):
    return user.groups.filter(name='Veterinario').exists()
def is_recepcionista(user):
    return user.groups.filter(name='Recepcionista').exists()

def logout_view(request):
    logout(request)  # Cierra la sesión del usuario
    return redirect('login')  # Redirige a donde desees

@login_required
def get_fichas_medicas(request, template_name='fichas_medicas.html'):

    query = request.GET.get('q', '').strip()
    resultados = []

    if query:
        resultados = Paciente.objects.filter(
            Q(rut_dueño__rut__icontains=query) | Q(id__icontains=query)
        )
    else:
        resultados = Paciente.objects.all()

    # Recuperar notificaciones del usuario autenticado
    notificaciones = []
    if request.user.is_authenticated:
        notificaciones = Notificacion.objects.filter(user=request.user).order_by('-created_at')

    # Verificar los grupos del usuario
    is_recepcionista = request.user.groups.filter(name='Recepcionista').exists()
    is_veterinario = request.user.groups.filter(name='Veterinario').exists()

    # Verifica si la solicitud es AJAX
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return render(request, 'resultados_parciales.html', {'resultados': resultados})

    # Si no es una solicitud AJAX, renderiza la página normalmente
    pacientes = Paciente.objects.all()  # Obtener todos los pacientes si no hay búsqueda
    context = {
        'pacientes': pacientes,
        'notificaciones': notificaciones,  # Asegúrate de pasar las notificaciones
        'is_recepcionista': is_recepcionista,
        'is_veterinario': is_veterinario,
    }
    print(context)
    return render(request, 'fichas_medicas.html', context)

@login_required
@user_passes_test(is_recepcionista)
def get_lista_reservas(request, template_name='lista_reservas.html'):
    query = request.GET.get('q', '').strip()
    resultados = []

    if query:
        resultados = Paciente.objects.filter(
            Q(rut_dueño__rut__icontains=query) | Q(id__icontains=query)
        )
    else:
        resultados = Paciente.objects.all()

    # Verifica si la solicitud es AJAX
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return render(request, 'resultados_parciales2.html', {'resultados': resultados})

    pacientes = Paciente.objects.all()
    servicios = Servicio.objects.all()
    especialistas = EspecialistaSalud.objects.all()

    especialistas = EspecialistaSalud.objects.prefetch_related(
        'disponibilidades'
    ).all()
    
    # Obtener el día actual como un número (1 para lunes, 7 para domingo)
    dia_actual = datetime.now().isoweekday()  # isoweekday devuelve 1 para lunes y 7 para domingo
    
    for especialista in especialistas:
        especialista.disponibilidades_ordenadas = especialista.disponibilidades.all().order_by('dia')

    return render(request, 'lista_reservas.html', {
        'pacientes': pacientes,
        'servicios': servicios,
        'especialistas': especialistas,
        'dia_actual': dia_actual,
    })


@login_required
def update_fallecido_status(request):
    print("Método de solicitud:", request.method)
    if request.method == 'POST':
        print("Datos recibidos:", request.POST)
        try:
            data = json.loads(request.body)
            paciente_id = data.get('paciente_id')
            is_fallecido = data.get('is_fallecido')

            # actualizar el estado en el modelo.
            paciente = Paciente.objects.get(id=paciente_id)
            paciente.fallecido = is_fallecido
            paciente.save()

            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

@login_required
@user_passes_test(is_recepcionista)
def registrar_paciente(request):
    if request.method == 'POST':
        # Obtener los datos del paciente
        nombre_1 = request.POST.get('nombre_1')
        nombre_2 = request.POST.get('nombre_2')
        apellido_1 = request.POST.get('apellido_1')
        apellido_2 = request.POST.get('apellido_2')
        especie_id = request.POST.get('especie')
        raza_id = request.POST.get('raza')
        sexo = request.POST.get('sexo')
        fecha_nacimiento = request.POST.get('fechaNacimiento')
        peso = request.POST.get('peso')
        años = request.POST.get('edadAnios')
        meses = request.POST.get('edadMeses')
        tatuaje = request.POST.get('tatuaje')
        color = request.POST.get('color')
        fecha_ingreso = request.POST.get('fechaIngreso')
        chip = request.POST.get('chip') == 'si'
        numero_chip = request.POST.get('numeroChip', None)
        alergia = request.POST.get('alergia') == 'si'
        tipo_alergia = request.POST.get('tipoAlergia', '')

        # Datos del dueño
        primer_nombre_dueno = request.POST.get('primerNombreDueno')
        segundo_nombre_dueno = request.POST.get('segundoNombreDueno')
        apellido_paterno_dueno = request.POST.get('apellidoPaterno')
        apellido_materno_dueno = request.POST.get('apellidoMaterno')
        rut = request.POST.get('rut')
        direccion = request.POST.get('direccion')
        telefono = request.POST.get('telefono')
        email = request.POST.get('correo')
        id_comuna = request.POST.get('comuna')
        # Guardar los datos en la base de datos
        try:
            comuna = get_object_or_404(Comuna, id=id_comuna)
            dueño, created = DueñoPaciente.objects.get_or_create(
                rut=rut,
                defaults={
                    'primer_nombre': primer_nombre_dueno,
                    'segundo_nombre': segundo_nombre_dueno,
                    'apellido_paterno': apellido_paterno_dueno,
                    'apellido_materno': apellido_materno_dueno,
                    'direccion': direccion,
                    'telefono': telefono,
                    'email': email,
                    'id_comuna': comuna
                }
            )

            # Verificar que la especie y raza existan
            print("se verifica que la especie existe")
            especie = get_object_or_404(Especie, id=especie_id)
            raza = get_object_or_404(Raza, id=raza_id)

            # Crear el paciente
            print("se crea el paciente")
            Paciente.objects.create(
                nombre_1=nombre_1,
                nombre_2=nombre_2,
                apellido_1=apellido_1,
                apellido_2=apellido_2,
                sexo=sexo,
                fecha_nacimiento=fecha_nacimiento,
                peso=peso,
                años=años,
                meses=meses,
                color=color,
                tatuaje=tatuaje,
                fecha_ingreso=fecha_ingreso,
                chip=chip,
                numero_chip=numero_chip,
                alergia=alergia,
                tipo_alergia=tipo_alergia,
                id_especie=especie,
                id_raza=raza,
                rut_dueño=dueño
            )
            """
            messages.success(request, 'Paciente registrado correctamente.')
            print("paciente creado correctamente")
            return redirect('get_fichas_medicas')  # Redirige a la lista de fichas médicas después de registrar
"""
        except Exception as e:
            messages.error(request, f'Error al registrar el paciente: {str(e)}')
            return redirect('registrar_paciente')

    especies = Especie.objects.all()
    razas = Raza.objects.all()
    comunas = Comuna.objects.all()
    return render(request, 'registro_paciente.html', {
        'especies': especies,
        'razas': razas,
        'comunas': comunas
    })


@login_required
def change_password(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        current_password = data.get('old_password')
        new_password = data.get('new_password1')
        confirm_password = data.get('new_password2')

        # Verificar que la contraseña actual es correcta
        if not request.user.check_password(current_password):
            return JsonResponse({'success': False, 'message': '* La contraseña actual es incorrecta.'})

        if new_password != confirm_password:
            return JsonResponse({'success': False, 'message': '* Las contraseñas nuevas no coinciden.'})

        # Cambiar la contraseña
        user = request.user
        user.set_password(new_password)
        user.save()
        update_session_auth_hash(request, user)  # Mantener la sesión del usuario activa
        return JsonResponse({'success': True, 'message': 'Contraseña cambiada correctamente.'})

    return JsonResponse({'success': False, 'message': 'Método no permitido.'})

@login_required
def update_profile(request):
    if request.method == 'POST':
        if not request.user.is_authenticated:
            return JsonResponse({'success': False, 'message': 'Usuario no autenticado.'}, status=403)

        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({'success': False, 'message': 'Datos JSON no válidos.'}, status=400)

        user = request.user

        # Variable para almacenar el mensaje de error
        error_message = None

        # Comprobar el nombre de usuario
        if 'username' in data:
            new_username = data['username']
            if User.objects.filter(username=new_username).exists() and new_username != user.username:
                error_message = 'El nombre de usuario ya está en uso.'

        # Comprobar el correo electrónico
        if 'email' in data:
            new_email = data['email']
            if User.objects.filter(email=new_email).exists() and new_email != user.email:
                error_message = 'El correo electrónico ya está en uso.'

        # Si hay un error, retornar el mensaje de error
        if error_message:
            return JsonResponse({'success': False, 'message': error_message}, status=400)

        # Actualizar los campos del usuario
        if 'first_name' in data:
            user.first_name = data['first_name']
        if 'last_name' in data:
            user.last_name = data['last_name']
        if 'username' in data:
            user.username = data['username']
        if 'email' in data:
            user.email = data['email']
  
        user.save()
        return JsonResponse({'success': True, 'message': 'Perfil actualizado correctamente.'})

    return JsonResponse({'success': False, 'message': 'Método no permitido.'}, status=405)

# VISTA OBTENER DETALLE FICHA PACIENTE (MODAL VER)
logger = logging.getLogger(__name__)
@login_required
def get_ficha_detalle(request, paciente_id):
    try:
        # Imprimir el ID recibido para debugging
        print(f"Buscando paciente con ID: {paciente_id}")
    
        paciente = get_object_or_404(Paciente, id=paciente_id)
        
        años = getattr(paciente, 'años', None)
        meses = getattr(paciente, 'meses', None)

        if años is None and meses is None:
            edad = "Desconocida"
        elif años is None:
            edad = f"{meses} meses"
        elif meses is None or meses == 0:
            edad = f"{años} años"
        else:
            edad = f"{años} año(s) {meses} mes(es)"

        # Crear el diccionario de datos con manejo de errores para cada campo
        data = {
            'paciente': {
                'nombre_1': getattr(paciente, 'nombre_1', ''),
                'nombre_2': getattr(paciente, 'nombre_2', ''),
                'apellido_1': getattr(paciente, 'apellido_1', ''),
                'apellido_2': getattr(paciente, 'apellido_2', ''),
                'especie': str(getattr(paciente, 'id_especie', '')),
                'raza': str(getattr(paciente, 'id_raza', '')),
                'sexo': getattr(paciente, 'sexo', ''),
                'fecha_nacimiento': paciente.fecha_nacimiento.strftime('%d/%m/%Y') if hasattr(paciente, 'fecha_nacimiento') and paciente.fecha_nacimiento else '',
                'edad' : edad,
                'peso': getattr(paciente, 'peso', ''),
                'color': getattr(paciente, 'color', ''),
                'fecha_ingreso': paciente.fecha_ingreso.strftime('%d/%m/%Y') if hasattr(paciente, 'fecha_ingreso') and paciente.fecha_ingreso else '',
                'tatuaje': getattr(paciente, 'tatuaje', ''),
                'chip': getattr(paciente, 'chip', False),
                'numero_chip': getattr(paciente, 'numero_chip', ''),
                'alergia': getattr(paciente, 'alergia', False),
                'tipo_alergia': getattr(paciente, 'tipo_alergia', ''),
            }
        }

        # Agregar datos del dueño
        if hasattr(paciente, 'rut_dueño') and paciente.rut_dueño:
            data['dueño'] = {
                'primer_nombre': getattr(paciente.rut_dueño, 'primer_nombre', ''),
                'segundo_nombre': getattr(paciente.rut_dueño, 'segundo_nombre', ''),
                'apellido_paterno': getattr(paciente.rut_dueño, 'apellido_paterno', ''),
                'apellido_materno': getattr(paciente.rut_dueño, 'apellido_materno', ''),
                'rut': getattr(paciente.rut_dueño, 'rut', ''),
                'id_comuna': str(getattr(paciente.rut_dueño, 'id_comuna', '')),
                'direccion': getattr(paciente.rut_dueño, 'direccion', ''),
                'telefono': getattr(paciente.rut_dueño, 'telefono', ''),
                'email': getattr(paciente.rut_dueño, 'email', ''),
            }
        else:
            data['dueño'] = {}

        print("Datos recuperados exitosamente:", data)
        return JsonResponse(data)

    except ObjectDoesNotExist as e:
        logger.error(f"Paciente no encontrado: {str(e)}")
        return JsonResponse({'error': 'Paciente no encontrado'}, status=404)
    except Exception as e:
        logger.error(f"Error al procesar la solicitud: {str(e)}")
        return JsonResponse({'error': f'Error del servidor: {str(e)}'}, status=500)
    


#EDITAR DATOS DEL PACIENTE: MODAL EDITAR

#VISTA PARA OBTENER PACIENTE (MODAL EDITAR)
@login_required
def obtener_datos_paciente(request, id_paciente):
    paciente = get_object_or_404(Paciente, id=id_paciente)
    dueño = paciente.rut_dueño  # Propietario asociado
    print("Sexo:", paciente.sexo)
    print("Alergia:", paciente.alergia)
    print("Chip:", paciente.chip)

    # Datos específicos del paciente
    data = {
        'paciente': {
            'nombre_1': paciente.nombre_1,
            'nombre_2': paciente.nombre_2,
            'apellido_1': paciente.apellido_1,
            'apellido_2': paciente.apellido_2,
            'especie_id': paciente.id_especie.id,
            'raza_id': paciente.id_raza.id,
            'sexo': paciente.sexo,
            'fecha_nacimiento': paciente.fecha_nacimiento.strftime('%Y-%m-%d') if paciente.fecha_nacimiento else '',
            'edad_años': paciente.años,
            'edad_meses': paciente.meses,
            'peso': paciente.peso,
            'color': paciente.color,
            'fecha_ingreso': paciente.fecha_ingreso.strftime('%Y-%m-%d') if paciente.fecha_ingreso else '',
            'tatuaje': paciente.tatuaje,
            'alergia': paciente.alergia,
            'tipo_alergia': paciente.tipo_alergia,
            'chip': paciente.chip,
            'numero_chip': paciente.numero_chip
        },
        'dueño': {
            'nombre': dueño.primer_nombre,
            'segundo_nombre': dueño.segundo_nombre,
            'apellido_paterno': dueño.apellido_paterno,
            'apellido_materno': dueño.apellido_materno,
            'comuna_id': dueño.id_comuna.id,
            'rut': dueño.rut,
            'direccion': dueño.direccion,
            'telefono': dueño.telefono,
            'email': dueño.email
        },
        # Agregar listas de opciones completas para especies, razas y comunas
        'opciones': {
            'especies': list(Especie.objects.values('id', 'nombre_especie')),
            'razas': list(Raza.objects.values('id', 'nombre_raza')),
            'comunas': list(Comuna.objects.values('id', 'nombre_comuna'))
        }
    }

    return JsonResponse(data)

# Función que registra en un archivo de log las ediciones realizadas en un sistema
# Recibe como parámetros el usuario que realiza la edición y el número de ficha del paciente
def log_edicion(usuario, num_ficha):

    # Verifica si el directorio de logs existe; si no, lo crea. (al estar trabajando todos juntos el LOG_DIR no es preciso y se debería crear una carpeta log por defecto)
    if not os.path.exists(LOG_DIR):
            os.makedirs(LOG_DIR)

   # Se define el nombre del archivo log utilizando la fecha actual en formato "YYYYMMDD.log"         
    log_filename = os.path.join(LOG_DIR, f"{datetime.now().strftime('%Y%m%d')}.log")

    # Abre el archivo de log en modo 'append' (añadir), para agregar registros sin sobrescribir
    with open(log_filename, 'a') as log_file:
        # Registra la edición
        # Escribe un registro de edición en el archivo de log
        log_file.write(f"\nFecha: {datetime.now().strftime('%Y-%m-%d')}\n")
        log_file.write(f"Hora: {datetime.now().strftime('%H:%M:%S')}\n")
        log_file.write(f"Usuario: {usuario.username}\n")
        log_file.write(f"Paciente: {num_ficha}\n\n")
        log_file.write("**********************\n")

#VISTA PARA ACTULIZAR PACIENTE (MODAL EDITAR)
@login_required
def actualizar_paciente(request, paciente_id):
    if request.method == "POST":
        paciente = get_object_or_404(Paciente, id=paciente_id)
        dueño = paciente.rut_dueño

        data = json.loads(request.body)

        # Obtener instancias de Especie y Raza según el ID
        especie_id = data['paciente'].get('especie_id')
        raza_id = data['paciente'].get('raza_id')
        
        # Recuperar las instancias de Especie y Raza
        especie = get_object_or_404(Especie, id=especie_id)
        raza = get_object_or_404(Raza, id=raza_id)

        # Asignar las instancias al paciente
        paciente.id_especie = especie
        paciente.id_raza = raza

        # Resto de la actualización del paciente
        paciente.nombre_1 = data['paciente']['nombre_1']
        paciente.nombre_2 = data['paciente']['nombre_2']
        paciente.apellido_1 = data['paciente']['apellido_1']
        paciente.apellido_2 = data['paciente']['apellido_2']
        
        # Asegurarnos que se recibe el valor correcto en `sexo`
        paciente.sexo = data['paciente']['sexo'] if data['paciente']['sexo'] in ['Macho', 'Hembra'] else paciente.sexo
        
        paciente.fecha_nacimiento = data['paciente']['fecha_nacimiento']
        paciente.años = int(data['paciente'].get('edad_años', 0))  
        paciente.meses = int(data['paciente'].get('edad_meses', 0))
        paciente.peso = data['paciente']['peso']
        paciente.color = data['paciente']['color']
        paciente.fecha_ingreso = data['paciente']['fecha_ingreso']
        paciente.tatuaje = data['paciente']['tatuaje']

        
        # Parseo de booleano para `alergia` y `chip` según valor recibido (SI o NO)
        paciente.alergia = data['paciente']['alergia'] == 'SI'
        paciente.chip = data['paciente']['chip'] == 'SI'
        
        # Solo asignar número de chip si `chip` es True
        paciente.numero_chip = data['paciente']['numero_chip'] if paciente.chip else None

        paciente.tipo_alergia = data['paciente']['tipo_alergia'] if paciente.alergia else None
        paciente.save()

        # Guardar datos del dueño
        dueño.primer_nombre = data['dueño']['nombre']
        dueño.segundo_nombre = data['dueño']['segundo_nombre']
        dueño.apellido_paterno = data['dueño']['apellido_paterno']
        dueño.apellido_materno = data['dueño']['apellido_materno']
        dueño.id_comuna_id = data['dueño']['comuna_id']
        dueño.direccion = data['dueño']['direccion']
        dueño.telefono = data['dueño']['telefono']
        dueño.email = data['dueño']['email']
        dueño.save()
        log_edicion(request.user, paciente.id)
        return JsonResponse({"mensaje": "Actualización exitosa"})
    else:
        return JsonResponse({"mensaje": "Método no permitido"}, status=405)


#VISTA PARA CREAR ATENCIÓN CLÍNICA (MODAL EDITAR)
@login_required
def crear_atencion(request, paciente_id):
    if request.method == 'POST':

        # Rescatar datos del formulario
        fecha_atencion = request.POST.get('fecha_atencion')
        hora_atencion = request.POST.get('hora_atencion')
        diagnostico = request.POST.get('diagnostico')
        tratamiento = request.POST.get('tratamiento')
        observacion = request.POST.get('observaciones')
        fecha_prox_atencion = request.POST.get('fecha_prox_atencion') or None
        fecha_prox_vacunacion = request.POST.get('fecha_prox_vacunacion') or None
        id_servicio = request.POST.get('servicio')
        id_especialista = request.POST.get('especialista')

        # Obtener la imagen de request.FILES
        imagen_rayos = request.FILES.get('imagen_rayos')

        # Recuperar el paciente
        paciente = get_object_or_404(Paciente, id=paciente_id)

        print("Datos recibidos:", {
    "fecha_atencion": fecha_atencion,
    "hora_atencion": hora_atencion,
    "diagnostico": diagnostico,
    "servicio_id": id_servicio,
    "especialista_id": id_especialista,
})

        try:
            # Obtener datos del formulario
            fecha_atencion = request.POST.get('fecha_atencion')
            hora_atencion = request.POST.get('hora_atencion')
            diagnostico = request.POST.get('diagnostico')
            tratamiento = request.POST.get('tratamiento')
            observacion = request.POST.get('observaciones')
            fecha_prox_atencion = request.POST.get('fecha_prox_atencion') or None
            fecha_prox_vacunacion = request.POST.get('fecha_prox_vacunacion') or None
            id_servicio = request.POST.get('servicio')
            id_especialista = request.POST.get('especialista')
            
            # Obtener la imagen de request.FILES
            imagen_rayos = request.FILES.get('imagen_rayos')

            # Recuperar el paciente
            paciente = get_object_or_404(Paciente, id=paciente_id)
            
            # Obtener servicio y especialista
            servicio = get_object_or_404(Servicio, id=id_servicio)
            especialista = get_object_or_404(EspecialistaSalud, id=id_especialista)

            # Crear la atención
            atencion = AtencionPaciente.objects.create(
                fecha_atencion=fecha_atencion,
                hora_atencion=hora_atencion,
                diagnostico=diagnostico,
                tratamiento=tratamiento,
                observacion=observacion,
                fecha_prox_atencion=fecha_prox_atencion,
                fecha_prox_vacunacion=fecha_prox_vacunacion,
                imagen_rayos=imagen_rayos,
                id_servicio=servicio,
                id_especialista=especialista,
                numero_ficha=paciente
            )

            return JsonResponse({"mensaje": "Atención creada exitosamente"})

        except Exception as e:
            print("Error al crear la atención:", str(e))
            return JsonResponse({"mensaje": f"Error al crear la atención: {str(e)}"}, status=500)
    else:
        return JsonResponse({"mensaje": "Método no permitido"}, status=405)



@login_required
def obtener_opciones_atencion(request):
    if request.method == 'GET':
        servicios = list(Servicio.objects.values('id', 'servicio'))
        especialistas = list(EspecialistaSalud.objects.values('id', 'primer_nombre', 'apellido_paterno'))

        return JsonResponse({'servicios': servicios, 'especialistas': especialistas})
    return JsonResponse({'error': 'Método no permitido'}, status=405)

@login_required
def obtener_atenciones(request, paciente_id):
    if request.method == 'GET':
        # Obtener todas las atenciones para el paciente
        atenciones = AtencionPaciente.objects.filter(numero_ficha_id=paciente_id).values(
            'id', 'fecha_atencion', 'hora_atencion', 'diagnostico', 'tratamiento', 
            'observacion', 'id_servicio__servicio', 'id_especialista__primer_nombre', 'id_especialista__apellido_paterno', 'fecha_prox_atencion', 'fecha_prox_vacunacion', 'imagen_rayos'
        )

        for atencion in atenciones:
            if atencion['imagen_rayos']:
                atencion['imagen_rayos'] = f"{settings.MEDIA_URL}{atencion['imagen_rayos']}"

        return JsonResponse(list(atenciones), safe=False)
    else:
        return JsonResponse({'error': 'Método no permitido'}, status=405)

@login_required
@user_passes_test(is_recepcionista)
def lista_especialistas(request):
    query = request.GET.get('q', '').strip()
    resultados = []

    if query:
        resultados = Paciente.objects.filter(
            Q(rut_dueño__rut__icontains=query) | Q(id__icontains=query)
        )
    else:
        resultados = Paciente.objects.all()

    # Filtra las reservas basadas en los pacientes encontrados
    reservas = Reserva.objects.filter(numero_ficha__in=resultados).select_related(
        'numero_ficha', 'especialista', 'especialidad', 'servicio'
    ).all()

    especialistas = EspecialistaSalud.objects.prefetch_related(
        'disponibilidades'
    ).all()
    
    dia_actual = datetime.now().isoweekday()
    
    for especialista in especialistas:
        especialista.disponibilidades_ordenadas = especialista.disponibilidades.all().order_by('dia')

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return render(request, 'resultados_parciales3.html', {'reservas': reservas})

    return render(request, 'prueba_disponibilidad.html', {
        'especialistas': especialistas,
        'dia_actual': dia_actual,
        'reservas': reservas,
    })

@login_required
def notificar_llegada(request, paciente_id, veterinario_id):
    if request.user.is_authenticated:
        # Obtener la instancia del usuario veterinario
        try:
            veterinario = User.objects.get(id=veterinario_id)
        except User.DoesNotExist:
            return JsonResponse({'status': 'Veterinario no encontrado'}, status=404)

        message = f'El paciente {paciente_id} ha llegado y está listo para ser atendido.'
        
        # Crear la notificación para el veterinario correcto
        notificacion = Notificacion.objects.create(user=veterinario, message=message)

        # Enviar la notificación a través de WebSocket
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f"notifications_{veterinario_id}",
            {
                'type': 'recibir_notificacion',
                'notificacion': {
                    'id': notificacion.id,
                    'message': notificacion.message,
                    'created_at': notificacion.created_at.strftime("%Y-%m-%d %H:%M"),
                    'is_read': notificacion.is_read,
                }
            }
        )
    
    return JsonResponse({'status': 'Notificación enviada'})

@login_required
def marcar_leida(request, notificacion_id):
    if request.method == 'POST' and request.user.is_authenticated:
        try:
            notificacion = Notificacion.objects.get(id=notificacion_id, user=request.user)
            print(notificacion.id)
            notificacion.is_read = True
            notificacion.save()
            print('Notificación marcada como leída:', notificacion.is_read)
            return JsonResponse({'status': 'Notificación marcada como leída'})
        except Notificacion.DoesNotExist:
            return JsonResponse({'status': 'Notificación no encontrada'}, status=404)
    return JsonResponse({'status': 'Método no permitido'}, status=405)

def test_view(request):
    notificaciones = Notificacion.objects.filter(user=request.user).order_by('-created_at') if request.user.is_authenticated else []
    return render(request, 'test_template.html', {'notificaciones': notificaciones})

def obtener_notificaciones(request):
    if request.user.is_authenticated:
        notificaciones = Notificacion.objects.filter(user=request.user, is_read=False).values('id', 'message', 'created_at', 'is_read')
        return JsonResponse(list(notificaciones), safe=False)
    return JsonResponse([], safe=False)


from django.views.decorators.http import require_POST

@login_required
@require_POST
def marcar_todo_como_leido(request):
    if request.user.is_authenticated:
        Notificacion.objects.filter(user=request.user, is_read=False).update(is_read=True)
        return JsonResponse({'status': 'Todas las notificaciones marcadas como leídas'})
    return JsonResponse({'status': 'No autorizado'}, status=403)

#Esta función obtiene el atributo valor_servicio para el formulario dinámico de reserva
@login_required
def obtener_valor_servicio(request, servicio_id):
    try:
        servicio = Servicio.objects.get(id=servicio_id)
        return JsonResponse({'valor': servicio.valor_servicio})
    except Servicio.DoesNotExist:
        return JsonResponse({'error': 'Servicio no encontrado'}, status=404)
    
#VISTAS PARA FUNCIÓN RESERVA: LÍNEAS DESDE LA 505 A LA 551
    
# Vista para listar pacientes y cargar el formulario de reservas
"""def get_lista_reservas(request):
    pacientes = Paciente.objects.all()
    servicios = Servicio.objects.all()
    especialistas = EspecialistaSalud.objects.all()

    especialistas = EspecialistaSalud.objects.prefetch_related(
        'disponibilidades'
    ).all()
    
    # Obtener el día actual como un número (1 para lunes, 7 para domingo)
    dia_actual = datetime.now().isoweekday()  # isoweekday devuelve 1 para lunes y 7 para domingo
    
    for especialista in especialistas:
        especialista.disponibilidades_ordenadas = especialista.disponibilidades.all().order_by('dia')

    return render(request, 'lista_reservas.html', {
        'pacientes': pacientes,
        'servicios': servicios,
        'especialistas': especialistas,
        'dia_actual': dia_actual,
    })"""

# Vista para guardar la reserva
@login_required
def guardar_reserva(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        ficha_id = data.get('fichaId')
        fecha = data.get('fecha')
        hora = data.get('hora')
        servicio_id = data.get('servicio')
        especialista_id = data.get('especialista')

        try:
            paciente = get_object_or_404(Paciente, id=ficha_id)
            servicio = get_object_or_404(Servicio, id=servicio_id)
            especialista = get_object_or_404(EspecialistaSalud, id=especialista_id)

            # Crear la reserva
            Reserva.objects.create(
                numero_ficha=paciente,
                fecha=fecha,
                hora=hora,
                servicio=servicio,
                especialista=especialista
            )
            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'message': str(e)})
    return JsonResponse({'success': False, 'message': 'Método no permitido'})

