#Se debe crear un archivo py que permita mapear los campos de nuestro modelo Paciente

from django import forms
from .models import Paciente, DueñoPaciente

#formulario paciente
class PacienteForm(forms.ModelForm):
    class Meta:
        model = Paciente
        fields = [
            'nombre_1', 'nombre_2', 'apellido_1', 'apellido_2', 'sexo',
            'fecha_nacimiento', 'peso', 'años', 'meses', 'color', 
            'tatuaje', 'fecha_ingreso', 'chip', 'numero_chip', 'alergia', 'tipo_alergia', 
            'id_especie', 'id_raza', 'rut_dueño']
        
#formulario dueño
class DueñoPacienteForm(forms.ModelForm):
    class Meta:
        model = DueñoPaciente
        fields = ['rut', 'primer_nombre', 'segundo_nombre', 'apellido_paterno', 'apellido_materno', 'direccion', 'telefono', 'email', 'id_comuna']
