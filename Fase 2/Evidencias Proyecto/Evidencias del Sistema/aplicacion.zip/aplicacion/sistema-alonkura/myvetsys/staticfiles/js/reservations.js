document.addEventListener('DOMContentLoaded', function () {
    // Establecer fecha mínima como hoy para el campo de fecha (en hora local)
    const fechaInput = document.getElementById('fecha_reserva');
    if (fechaInput) {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, '0'); // Los meses van de 0 a 11
        const day = String(today.getDate()).padStart(2, '0');
        const formattedDate = `${year}-${month}-${day}`;
        fechaInput.min = formattedDate;
    }
    
    // Función para abrir el modal de reserva
    window.abrirModalReserva = function (fichaId, nombrePaciente) {
        document.getElementById('fichaId').value = fichaId;
        document.getElementById('nombrePaciente').value = nombrePaciente;
        const modal = new bootstrap.Modal(document.getElementById('modalReserva'));
        modal.show();
    };

    // Actualizar el valor del servicio al seleccionar uno del campo desplegable
    const servicioSelect = document.getElementById('servicio');
    const valorServicioInput = document.getElementById('valor_servicio');
    
    if (servicioSelect && valorServicioInput) {
        servicioSelect.addEventListener('change', function () {
            const servicioId = this.value;
            if (servicioId) {
                fetch(`/obtener-valor-servicio/${servicioId}/`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error al obtener el valor del servicio');
                        }
                        return response.json();
                    })
                    .then(data => {
                        valorServicioInput.value = `$${data.valor}`;
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire('Error', 'No se pudo obtener el valor del servicio', 'error');
                    });
            } else {
                valorServicioInput.value = '';
            }
        });
    }

    // Función para guardar la reserva
    const guardarReservaBtn = document.getElementById('guardarReserva');
    if (guardarReservaBtn) {
        guardarReservaBtn.addEventListener('click', function () {
            const formData = {
                fichaId: document.getElementById('fichaId').value,
                fecha: document.getElementById('fecha_reserva').value,
                hora: document.getElementById('hora_reserva').value,
                servicio: servicioSelect.value,
                especialista: document.getElementById('especialista').value
            };

            fetch('/guardar-reserva/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: "¡Enhorabuena!\n Reserva registrada exitosamente.",
                        text: "Se ha registrado una reserva para este paciente correctamente.",
                        icon: "success",
                        confirmButtonText: "Aceptar"
                    }).then(() => {
                            const modal = bootstrap.Modal.getInstance(document.getElementById('modalReserva'));
                            modal.hide();
                            window.location.reload();
                        });
                } else {
                    Swal.fire('Error', data.message || 'Error al guardar la reserva', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire('Error', 'Error al procesar la solicitud', 'error');
            });
        });
    }
});

// Función para obtener el token CSRF
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

    // evento para abrir el modal
    function openModal() {
        document.getElementById("reservaModal").style.display = "block";
    }
    
    function closeModal() {
        document.getElementById("reservaModal").style.display = "none";
    }
    
    // Cerrar modal si se hace clic fuera de él
    window.onclick = function(event) {
        var modal = document.getElementById("reservaModal");
        if (event.target == modal) {
            closeModal();
        }
    }