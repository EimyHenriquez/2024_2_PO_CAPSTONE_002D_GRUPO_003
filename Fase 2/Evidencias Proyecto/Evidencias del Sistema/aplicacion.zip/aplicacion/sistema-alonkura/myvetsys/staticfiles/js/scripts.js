/* Funciones dinámicas del formulario de registro Líneas de la 2-72 */
document.addEventListener('DOMContentLoaded', function() {
    const seccionPaciente = document.getElementById('seccionPaciente');
    const seccionDueno = document.getElementById('seccionDueno');
    const btnSiguiente = document.getElementById('btnSiguiente');
    const btnRegistrar = document.getElementById('btnRegistrar');
    const chipSi = document.getElementById('chipSi');
    const chipNo = document.getElementById('chipNo');
    const numeroChip = document.getElementById('numeroChip');
    const alergiaSi = document.getElementById('alergiaSi');
    const alergiaNo = document.getElementById('alergiaNo');
    const tipoAlergiaContainer = document.getElementById('tipoAlergiaContainer');

    btnSiguiente.addEventListener('click', function() {
        if (validarSeccionPaciente()) {
            seccionDueno.classList.remove('disabled-section');
            btnSiguiente.style.display = 'none';
            btnRegistrar.disabled = false;
            document.querySelector('#seccionDueno input').focus();
        }
    });

    function validarSeccionPaciente() {
        const camposRequeridos = seccionPaciente.querySelectorAll('[required]');
        for (let campo of camposRequeridos) {
            if (!campo.value) {
                alert('Por favor, complete todos los campos requeridos en la sección del paciente.');
                campo.focus();
                return false;
            }
        }
        return true;
    }

    chipSi.addEventListener('change', function() {
        numeroChip.disabled = !this.checked;
    });

    chipNo.addEventListener('change', function() {
        numeroChip.disabled = this.checked;
        if (this.checked) {
            numeroChip.value = '';
        }
    });

    alergiaSi.addEventListener('change', function() {
        tipoAlergiaContainer.style.display = this.checked ? 'block' : 'none';
    });

    alergiaNo.addEventListener('change', function() {
        tipoAlergiaContainer.style.display = 'none';
    });

    document.getElementById('registroForm').addEventListener('submit', function(e) {
        if (!validarFormularioCompleto()) {
            e.preventDefault(); // Solo previene el envío si la validación falla
        } else {
            console.log('Formulario enviado');
            document.getElementById('registroForm').submit();
            console.log('Post formulario');
        }
    });

    function validarFormularioCompleto() {
        const camposRequeridos = document.querySelectorAll('[required]');
        for (let campo of camposRequeridos) {
            if (!campo.value) {
                alert('Por favor, complete todos los campos requeridos antes de registrar.');
                campo.focus();
                return false;
            }
        }
        return true;
    }
});

/*Funciones dinámicas checkbox fallecido Líneas de la 75-159*/
/*const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
        confirmButton: "btn btn-success mx-2",
        cancelButton: "btn btn-danger mx-2"
    },
    buttonsStyling: false
});*/
/*
function showFallecidoConfirmation(checkbox) {
    const pacienteId = checkbox.dataset.id;
    const pacienteNombre = checkbox.dataset.nombre;
    const isChecked = checkbox.checked;

    const title = isChecked ? "¿Marcar como fallecido?" : "¿Desmarcar como fallecido?";
    const text = isChecked 
        ? `¿Estás seguro de que deseas marcar a ${pacienteNombre} (ID: ${pacienteId}) como fallecido?`
        : `¿Estás seguro de que deseas desmarcar a ${pacienteNombre} (ID: ${pacienteId}) como fallecido?`;
    const confirmButtonText = isChecked ? "Sí, marcar como fallecido" : "Sí, desmarcar";
    const successText = isChecked 
        ? `${pacienteNombre} ha sido marcado como fallecido.`
        : `${pacienteNombre} ha sido desmarcado como fallecido.`;

    swalWithBootstrapButtons.fire({
        title: title,
        text: text,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: confirmButtonText,
        cancelButtonText: "Cancelar",
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            // Send AJAX request to update the database
            fetch('/update_fallecido_status/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCookie('csrftoken')
                },
                body: JSON.stringify({
                    paciente_id: pacienteId,
                    is_fallecido: isChecked
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    swalWithBootstrapButtons.fire({
                        title: "Confirmado",
                        text: successText,
                        icon: "success"
                    });
                    checkbox.checked = isChecked;
                } else {
                    throw new Error('Failed to update status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                swalWithBootstrapButtons.fire({
                    title: "Error",
                    text: "Hubo un problema al actualizar el estado. Por favor, inténtalo de nuevo.",
                    icon: "error"
                });
                checkbox.checked = !isChecked;
            });
        } else if (result.dismiss === Swal.DismissReason.cancel) {
            swalWithBootstrapButtons.fire({
                title: "Cancelado",
                text: "No se ha realizado ningún cambio",
                icon: "error"
            });
            checkbox.checked = !isChecked;
        }
    });
}/*
/*
document.addEventListener('DOMContentLoaded', function() {
    const fallecidoCheckboxes = document.querySelectorAll('.paciente-fallecido');
    fallecidoCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function(event) {
            event.preventDefault();
            showFallecidoConfirmation(this);
        });
    });
});*/
/*
// Function to get CSRF token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}*/

/*FUNCIONES PARA ACTUALIZAR DATOS DEL PACIENTE Y DE DUEÑO PACIENTE: (MODAL EDITAR)
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.editar-ficha').forEach(button => {
        button.addEventListener('click', function () {
            const idPaciente = this.getAttribute('data-id');
            document.getElementById('modalFichaMedica').setAttribute('data-current-patient', idPaciente);
            cargarDatosPaciente(idPaciente);
        });
    });
    

    function cargarDatosPaciente(idPaciente) {
        fetch(`/obtener_datos_paciente/${idPaciente}/`)
            .then(response => response.json())
            .then(data => {
                console.log('Datos recibidos del servidor:', data);

                // Cargar datos del paciente en el modal con verificación de nulidad
                document.getElementById('edit_nombre1').value = data.paciente.nombre_1 || '';
                document.getElementById('edit_nombre2').value = data.paciente.nombre_2 || '';
                document.getElementById('edit_apellido1').value = data.paciente.apellido_1 || '';
                document.getElementById('edit_apellido2').value = data.paciente.apellido_2 || '';
                document.getElementById('edit_tatuaje').value = data.paciente.tatuaje || '';
                document.getElementById('edit_tipo_alergia').value = data.paciente.tipo_alergia || '';
                document.getElementById('edit_numero_chip').value = data.paciente.numero_chip || '';
                document.getElementById('edit_fecha_nacimiento').value = data.paciente.fecha_nacimiento || '';
                document.getElementById('edit_edadAnios').value = data.paciente.edad_años || 0; 
                document.getElementById('edit_edadMeses').value = data.paciente.edad_meses || 0;
                document.getElementById('edit_peso').value = data.paciente.peso || '';
                document.getElementById('edit_color').value = data.paciente.color || '';
                document.getElementById('edit_fecha_ingreso').value = data.paciente.fecha_ingreso || '';


                if (data.paciente.sexo === "Macho") {
                    document.getElementById("edit_sexo_macho").checked = true;
                } else if (data.paciente.sexo === "Hembra") {
                    document.getElementById("edit_sexo_hembra").checked = true;
                }
                // Manejo específico para radio buttons de chip
                console.log(data.paciente.chip)
                if (data.paciente.chip === true) {
                    document.getElementById('edit_chip_si').checked = true;
                    document.getElementById('edit_numero_chip').value = data.numero_chip || '';
                    document.getElementById('edit_numero_chip').disabled = false;
                } else {
                    document.getElementById('edit_chip_no').checked = true;
                    document.getElementById('edit_numero_chip').value = '';
                    document.getElementById('edit_numero_chip').disabled = true;
                }

                // Manejo específico para radio buttons de alergia
                console.log(data.paciente.alergia)
                if (data.paciente.alergia === true) {
                    document.getElementById('edit_alergia_si').checked = true;
                    document.getElementById('edit_tipo_alergia').value = data.tipo_alergia;
                    document.getElementById('edit_tipo_alergia').disabled = false;
                } else {
                    document.getElementById('edit_alergia_no').checked = true;
                    document.getElementById('edit_tipo_alergia').value = '';
                    document.getElementById('edit_tipo_alergia').disabled = true;
                }

                document.getElementById('edit_numero_chip').value = data.paciente.numero_chip || '';
                document.getElementById('edit_tipo_alergia').value = data.paciente.tipo_alergia || '';

                // Cargar especie, raza, comuna
                const especieSelect = document.getElementById('edit_especie');
                if (especieSelect) {
                    especieSelect.innerHTML = '';
                    data.opciones.especies.forEach(especie => {
                        const option = document.createElement('option');
                        option.value = especie.id;
                        option.textContent = especie.nombre_especie;
                        if (especie.id === data.paciente.especie_id) {
                            option.selected = true;
                        }
                        especieSelect.appendChild(option);
                    });
                }

                const razaSelect = document.getElementById('edit_raza');
                if (razaSelect) {
                    razaSelect.innerHTML = '';
                    data.opciones.razas.forEach(raza => {
                        const option = document.createElement('option');
                        option.value = raza.id;
                        option.textContent = raza.nombre_raza;
                        if (raza.id === data.paciente.raza_id) {
                            option.selected = true;
                        }
                        razaSelect.appendChild(option);
                    });
                }

                const comunaSelect = document.getElementById('edit_dueño_comuna');
                if (comunaSelect) {
                    comunaSelect.innerHTML = '';
                    data.opciones.comunas.forEach(comuna => {
                        const option = document.createElement('option');
                        option.value = comuna.id;
                        option.textContent = comuna.nombre_comuna;
                        if (comuna.id === data.dueño.comuna_id) {
                            option.selected = true;
                        }
                        comunaSelect.appendChild(option);
                    });
                }

                // Cargar datos del dueño
                document.getElementById('edit_dueño_rut').value = data.dueño.rut || '';
                document.getElementById('edit_dueño_nombre').value = data.dueño.nombre || '';
                document.getElementById('edit_dueño_segundo_nombre').value = data.dueño.segundo_nombre || '';
                document.getElementById('edit_dueño_apellido_paterno').value = data.dueño.apellido_paterno || '';
                document.getElementById('edit_dueño_apellido_materno').value = data.dueño.apellido_materno || '';
                document.getElementById('edit_dueño_direccion').value = data.dueño.direccion || '';
                document.getElementById('edit_dueño_telefono').value = data.dueño.telefono || '';
                document.getElementById('edit_dueño_email').value = data.dueño.email || '';
            })
            .catch(error => {
                console.error('Error al cargar los datos del paciente:', error);
                alert('Hubo un error al cargar los datos del paciente');
            });
    }
    

    
    

    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
});

document.addEventListener('DOMContentLoaded', function() {
    //Manejo de radio buttons de chip
    const chipRadios = document.querySelectorAll('input[name="edit_chip"]');
    const numeroChipInput = document.getElementById('edit_numero_chip');

    chipRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            numeroChipInput.disabled = this.value === 'No';
            if (this.value === 'No') {
                numeroChipInput.value = '';
            }
        });
    });

    // Manejo de radio buttons de alergia
    const alergiaRadios = document.querySelectorAll('input[name="edit_alergia"]');
    const tipoAlergiaInput = document.getElementById('edit_tipo_alergia');

    alergiaRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            tipoAlergiaInput.disabled = this.value === 'No';
            if (this.value === 'No') {
                tipoAlergiaInput.value = '';
            }
        });
    });
});
*/

/*FUNCIÓN CREAR ATENCIÓN CLÍNICA: (MODAL EDITAR)
document.addEventListener('DOMContentLoaded', function () {
    function cargarSelectores() {
        const servicioSelect = document.getElementById('servicio');
        const especialistaSelect = document.getElementById('especialista');

        // Cargar servicios y especialistas
        fetch('/obtener_opciones_atencion/')
            .then(response => response.json())
            .then(data => {
                // Llenar selector de servicios
                servicioSelect.innerHTML = '<option value="">Seleccione un servicio...</option>';
                data.servicios.forEach(servicio => {
                    const option = document.createElement('option');
                    option.value = servicio.id;
                    option.textContent = servicio.servicio;
                    servicioSelect.appendChild(option);
                });

                // Llenar selector de especialistas
                especialistaSelect.innerHTML = '<option value="">Seleccione un especialista...</option>';
                data.especialistas.forEach(especialista => {
                    const option = document.createElement('option');
                    option.value = especialista.id;
                    option.textContent = `${especialista.primer_nombre} ${especialista.apellido_paterno}`;
                    especialistaSelect.appendChild(option);
                });
            })
            .catch(error => console.error('Error al cargar opciones:', error));
    }

    document.getElementById('crearNuevaAtencion').addEventListener('click', function (e) {
        e.preventDefault();
    
        const pacienteId = document.getElementById('modalFichaMedica').getAttribute('data-current-patient');
        const url = `/crear_atencion/${pacienteId}/`;
    
        // Crear FormData
        const formData = new FormData();
        
        // Agregar todos los campos al FormData
        formData.append('fecha_atencion', document.getElementById('fecha_atencion').value);
        formData.append('hora_atencion', document.getElementById('hora_atencion').value);
        formData.append('diagnostico', document.getElementById('diagnostico').value);
        formData.append('tratamiento', document.getElementById('tratamiento').value);
        formData.append('observaciones', document.getElementById('observaciones').value);
        formData.append('servicio', document.getElementById('servicio').value);
        formData.append('especialista', document.getElementById('especialista').value);
    
        // Agregar fechas solo si tienen valor
        const fechaProxAtencion = document.getElementById('fecha_prox_atencion').value;
        const fechaProxVacunacion = document.getElementById('fecha_prox_vacunacion').value;
        
        if (fechaProxAtencion) {
            formData.append('fecha_prox_atencion', fechaProxAtencion);
        }
        if (fechaProxVacunacion) {
            formData.append('fecha_prox_vacunacion', fechaProxVacunacion);
        }
    
        // Agregar la imagen si existe
        const imagenInput = document.getElementById('imagenologia');
        if (imagenInput && imagenInput.files[0]) {
            formData.append('imagen_rayos', imagenInput.files[0]);
        }
    
        // Mostrar SweetAlert de carga
        Swal.fire({
            title: "Registrando atención clínica...",
            html: "Por favor, espera unos segundos mientras procesamos los datos.",
            timer: 2000,
            timerProgressBar: true,
            didOpen: () => {
                Swal.showLoading();
            }
        }).then(() => {
            fetch(url, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                },
                // No incluir 'Content-Type' header, el navegador lo configurará automáticamente
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(data => {
                        throw new Error(data.mensaje || `HTTP error! status: ${response.status}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                Swal.fire({
                    title: "¡Atención clínica registrada!",
                    text: "La atención clínica ha sido registrada con éxito.",
                    icon: "success",
                    confirmButtonText: "Aceptar"
                }).then(() => {
                    $('#modalFichaMedica').modal('hide');
                    // Aquí puedes agregar código para actualizar la vista si es necesario
                });
            })
            .catch(error => {
                console.error("Error en la solicitud:", error);
                Swal.fire({
                    title: "Error",
                    text: error.message || "Hubo un problema al crear la atención",
                    icon: "error",
                    confirmButtonText: "Aceptar"
                });
            });
        });
    });
    
    

    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }

    // Cargar selectores al abrir el modal
    document.querySelectorAll('.editar-ficha').forEach(button => {
        button.addEventListener('click', function () {
            const idPaciente = this.getAttribute('data-id');
            document.getElementById('modalFichaMedica').setAttribute('data-current-patient', idPaciente);
            cargarSelectores();
        });
    });

    // Función para limpiar los campos del formulario de creación de atención
    function limpiarFormularioAtencion() {
        document.getElementById('fecha_atencion').value = '';
        document.getElementById('hora_atencion').value = '';
        document.getElementById('diagnostico').value = '';
        document.getElementById('tratamiento').value = '';
        document.getElementById('observaciones').value = '';
        document.getElementById('servicio').value = '';
        document.getElementById('especialista').value = '';
        document.getElementById('imagenologia').value = ''; // Si tienes un campo de archivo
        document.getElementById('fecha_prox_atencion').value = '';
        document.getElementById('fecha_prox_vacunacion').value = '';
    }

    // Llama a la función limpiarFormularioAtencion cuando se cierre el modal de edición
    document.getElementById('modalFichaMedica').addEventListener('hidden.bs.modal', function () {
        limpiarFormularioAtencion();
    });
});

/*

/*FUNCIÓN PARA LISTAR LAS ATENCIONES CLÍNICAS
document.addEventListener('DOMContentLoaded', function () {
    function cargarAtenciones(pacienteId) {
        fetch(`/obtener_atenciones/${pacienteId}/`)
            .then(response => response.json())
            .then(atenciones => {
                const tbody = document.querySelector('#tablaAtenciones tbody');
                tbody.innerHTML = '';

                atenciones.forEach(atencion => {
                    const fila = document.createElement('tr');
                    
                    // Verificar si la imagen de rayos existe
                    let imagenRayosHtml = '';
                    if (atencion.imagen_rayos) {
                        const imagenUrl = `${atencion.imagen_rayos}`;
                        imagenRayosHtml = `
                            <a href="${imagenUrl}" download="Imagen_Rayos_X_${atencion.id}" class="btn btn-outline-primary btn-sm">Descargar</a>`;
                    } else {
                        imagenRayosHtml = '<span>Sin imagen</span>';
                    }

                    fila.innerHTML = `
                        <td>${atencion.id}</td>
                        <td>${atencion.fecha_atencion}</td>
                        <td>${atencion.hora_atencion}</td>
                        <td>${atencion.id_servicio__servicio}</td>
                        <td>${atencion.id_especialista__primer_nombre} ${atencion.id_especialista__apellido_paterno}</td>
                        <td>${atencion.diagnostico}</td>
                        <td>${atencion.tratamiento}</td>
                        <td>${atencion.observacion}</td>
                        <td>${imagenRayosHtml}</td>
                        <td>${atencion.fecha_prox_atencion || '-'}</td>
                        <td>${atencion.fecha_prox_vacunacion || '-'}</td>
                    `;
                    tbody.appendChild(fila);
                });
            })
            .catch(error => console.error('Error al cargar las atenciones:', error));
    }

    // Asignar eventos para los botones Ver Ficha
    document.querySelectorAll('.ver-ficha').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const pacienteId = this.getAttribute('data-id');
            cargarAtenciones(pacienteId);
        });
    });
});


*/